# FitterField™ Website

Mobile-first HTTPS-ready marketing/sales site for FitterField.

## Deploy on Render

1. Create a new **Static Site** on Render.
2. Upload this folder to a GitHub repository or connect the repository.
3. Set the publish directory to `.` (the included `render.yaml` can also be used with a Blueprint).
4. Deploy.

Render provides a free managed TLS certificate and automatically redirects HTTP to HTTPS for the Render subdomain and custom domains.

## IMPORTANT before taking payments

The Buy button is intentionally not connected to a payment processor yet.

Replace the `href="#"` on the **Get FitterField Pro** button in `index.html` with:
- a Stripe Payment Link,
- a Payhip checkout URL,
- a Gumroad product URL,
- or your own FitterField app checkout route.

Do not put secret Stripe API keys in this static website.

## Email

Customer support/contact email is set to:

mhancock1992@icloud.com

If you later buy a domain (for example `fitterfield.com`) and have iCloud+, Apple supports custom-domain iCloud Mail, so you could use addresses such as `support@fitterfield.com` while continuing to use the Apple Mail/iCloud ecosystem.

## Product disclaimer

The site deliberately states that FitterField is an independent educational/productivity tool and does not replace applicable codes, standards, engineering/design requirements, manufacturer instructions, employer procedures, qualified supervision, or formal training. Review all technical content before publishing.
